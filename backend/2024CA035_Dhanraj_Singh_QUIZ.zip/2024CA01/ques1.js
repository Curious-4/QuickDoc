const xmlString = `
<root>
  <data>&ext;</data>
</root>
`;

const parser = new DOMParser();
const xmlDoc = parser.parseFromString(xmlString, "application/xml");

const dataElement = xmlDoc.getElementsByTagName("data")[0];
const content = dataElement.textContent;

console.log("Content of <data>:", content);
